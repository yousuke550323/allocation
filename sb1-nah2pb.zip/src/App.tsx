import React, { useState } from 'react';
import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom';
import { Truck, Plus, X, LayoutDashboard, FileText, Calendar, ClipboardCheck } from 'lucide-react';
import DeliveryRequestForm from './components/DeliveryRequestForm';
import Dashboard from './components/Dashboard';
import PriceListPage from './pages/PriceListPage';
import ScheduleAdjustment from './components/ScheduleAdjustment';
import CompletionReportForm from './components/CompletionReportForm';

function App() {
  const [showForm, setShowForm] = useState(false);
  const [showSchedule, setShowSchedule] = useState(false);
  const [deliveries, setDeliveries] = useState([]);

  const addDelivery = (delivery) => {
    setDeliveries([...deliveries, { ...delivery, id: Date.now(), status: '未確定' }]);
    setShowForm(false);
  };

  const updateDeliveryStatus = (id, status) => {
    setDeliveries(deliveries.map(d => d.id === id ? { ...d, status } : d));
  };

  const updateDeliveryNotes = (id, notes) => {
    setDeliveries(deliveries.map(d => d.id === id ? { ...d, notes } : d));
  };

  const confirmSchedule = (id, scheduledDate) => {
    setDeliveries(deliveries.map(d => d.id === id ? { ...d, status: '完了待ち', scheduledDate } : d));
  };

  const updateDelivery = (updatedDelivery) => {
    setDeliveries(deliveries.map(d => d.id === updatedDelivery.id ? updatedDelivery : d));
  };

  return (
    <Router>
      <div className="min-h-screen bg-pink-50">
        <header className="bg-pink-200 text-pink-800 p-4 shadow-md">
          <div className="container mx-auto flex justify-between items-center">
            <h1 className="text-2xl font-bold flex items-center">
              <Truck className="mr-2" /> 配送管理システム
            </h1>
            <nav>
              <ul className="flex space-x-4">
                <li>
                  <Link
                    to="/"
                    className="bg-pink-100 text-pink-600 px-4 py-2 rounded-full flex items-center hover:bg-pink-300 transition duration-300"
                  >
                    <LayoutDashboard className="mr-1" size={18} /> ダッシュボード
                  </Link>
                </li>
                <li>
                  <Link
                    to="/price-list"
                    className="bg-pink-100 text-pink-600 px-4 py-2 rounded-full flex items-center hover:bg-pink-300 transition duration-300"
                  >
                    <FileText className="mr-1" size={18} /> 料金表
                  </Link>
                </li>
                <li>
                  <button
                    onClick={() => setShowSchedule(true)}
                    className="bg-pink-100 text-pink-600 px-4 py-2 rounded-full flex items-center hover:bg-pink-300 transition duration-300"
                  >
                    <Calendar className="mr-1" size={18} /> 日程調整
                  </button>
                </li>
                <li>
                  <Link
                    to="/completion-report"
                    className="bg-pink-100 text-pink-600 px-4 py-2 rounded-full flex items-center hover:bg-pink-300 transition duration-300"
                  >
                    <ClipboardCheck className="mr-1" size={18} /> 完了報告作成
                  </Link>
                </li>
                <li>
                  <button
                    onClick={() => setShowForm(true)}
                    className="bg-pink-100 text-pink-600 px-4 py-2 rounded-full flex items-center hover:bg-pink-300 transition duration-300"
                  >
                    <Plus className="mr-1" size={18} /> 新規依頼
                  </button>
                </li>
              </ul>
            </nav>
          </div>
        </header>

        <main className="container mx-auto p-4">
          <Routes>
            <Route path="/" element={<Dashboard deliveries={deliveries} updateStatus={updateDeliveryStatus} updateNotes={updateDeliveryNotes} />} />
            <Route path="/price-list" element={<PriceListPage />} />
            <Route path="/completion-report" element={<CompletionReportForm deliveries={deliveries} updateDelivery={updateDelivery} />} />
          </Routes>
        </main>

        {showForm && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 overflow-y-auto z-50">
            <div className="bg-white rounded-lg p-6 w-full max-w-2xl">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-bold text-pink-800">新規配送依頼</h2>
                <button onClick={() => setShowForm(false)} className="text-pink-500 hover:text-pink-700">
                  <X size={24} />
                </button>
              </div>
              <DeliveryRequestForm onSubmit={addDelivery} />
            </div>
          </div>
        )}

        {showSchedule && (
          <ScheduleAdjustment
            deliveries={deliveries.filter(d => d.status === '未確定')}
            onClose={() => setShowSchedule(false)}
            onConfirm={confirmSchedule}
          />
        )}
      </div>
    </Router>
  );
}

export default App;