import React, { useState } from 'react';
import { X, Search } from 'lucide-react';

const ScheduleAdjustment = ({ deliveries, onClose, onConfirm }) => {
  const [selectedDelivery, setSelectedDelivery] = useState(null);
  const [scheduledDate, setScheduledDate] = useState('');
  const [searchTerm, setSearchTerm] = useState('');

  const handleConfirm = () => {
    if (selectedDelivery && scheduledDate) {
      onConfirm(selectedDelivery.id, scheduledDate);
      setSelectedDelivery(null);
      setScheduledDate('');
    }
  };

  const filteredDeliveries = deliveries.filter(d => 
    d.workOrderNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
    d.customerName.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-lg p-6 w-full max-w-4xl">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold text-pink-800">日程調整</h2>
          <button onClick={onClose} className="text-pink-500 hover:text-pink-700">
            <X size={24} />
          </button>
        </div>
        <div className="mb-4">
          <label htmlFor="search" className="block text-sm font-medium text-pink-700">配送依頼検索</label>
          <div className="mt-1 relative rounded-md shadow-sm">
            <input
              type="text"
              id="search"
              className="focus:ring-pink-500 focus:border-pink-500 block w-full pl-10 sm:text-sm border-pink-300 rounded-md"
              placeholder="作業番号または顧客名で検索"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-5 w-5 text-gray-400" />
            </div>
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <h3 className="text-lg font-semibold mb-2">未確定の配送依頼</h3>
            {filteredDeliveries.length === 0 ? (
              <p>未確定の配送依頼はありません。</p>
            ) : (
              <ul className="space-y-2">
                {filteredDeliveries.map((delivery) => (
                  <li
                    key={delivery.id}
                    className={`p-2 rounded cursor-pointer ${
                      selectedDelivery?.id === delivery.id ? 'bg-pink-100' : 'hover:bg-pink-50'
                    }`}
                    onClick={() => setSelectedDelivery(delivery)}
                  >
                    <p className="font-semibold">{delivery.customerName}</p>
                    <p className="text-sm text-gray-600">{delivery.workOrderNumber}</p>
                    <p className="text-sm text-gray-600">{delivery.customerAddress}</p>
                  </li>
                ))}
              </ul>
            )}
          </div>
          <div>
            {selectedDelivery && (
              <div>
                <h3 className="text-lg font-semibold mb-2">日程設定</h3>
                <p><strong>作業番号:</strong> {selectedDelivery.workOrderNumber}</p>
                <p><strong>お客様名:</strong> {selectedDelivery.customerName}</p>
                <p><strong>住所:</strong> {selectedDelivery.customerAddress}</p>
                <p><strong>連絡先:</strong> {selectedDelivery.contactNumber}</p>
                <div className="mt-4">
                  <label htmlFor="scheduledDate" className="block text-sm font-medium text-pink-700">
                    配送日時
                  </label>
                  <input
                    type="datetime-local"
                    id="scheduledDate"
                    value={scheduledDate}
                    onChange={(e) => setScheduledDate(e.target.value)}
                    className="mt-1 block w-full rounded-md border-pink-300 shadow-sm focus:border-pink-300 focus:ring focus:ring-pink-200 focus:ring-opacity-50"
                  />
                </div>
                <button
                  onClick={handleConfirm}
                  disabled={!scheduledDate}
                  className="mt-4 bg-pink-500 text-white py-2 px-4 rounded-md hover:bg-pink-600 focus:outline-none focus:ring-2 focus:ring-pink-500 focus:ring-opacity-50 transition duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  日程確定
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ScheduleAdjustment;