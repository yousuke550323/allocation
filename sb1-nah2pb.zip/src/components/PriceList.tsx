import React from 'react';

export interface PriceItem {
  id: string;
  name: string;
  price: number;
  category: string;
  subCategory?: string;
}

const priceList: PriceItem[] = [
  { id: '1', name: '冷蔵庫600L以上', price: 19000, category: '設置' },
  { id: '2', name: '冷蔵庫600L以上', price: 17000, category: '設置', subCategory: '搬出のみ' },
  { id: '3', name: '冷蔵庫500-599L', price: 17000, category: '設置' },
  { id: '4', name: '冷蔵庫500-599L', price: 14500, category: '設置', subCategory: '搬出のみ' },
  { id: '5', name: '冷蔵庫400-499L', price: 14500, category: '設置' },
  { id: '6', name: '冷蔵庫400-499L', price: 9900, category: '設置', subCategory: '搬出のみ' },
  { id: '7', name: '冷蔵庫400L未満', price: 7000, category: '設置' },
  { id: '8', name: '冷蔵庫400L未満', price: 6500, category: '設置', subCategory: '搬出のみ' },
  { id: '9', name: 'ドラム式洗濯機75kg以上', price: 12800, category: '設置' },
  { id: '10', name: 'ドラム式洗濯機75kg以上', price: 11200, category: '設置', subCategory: '搬出のみ' },
  { id: '11', name: 'ドラム式洗濯機75kg未満', price: 7000, category: '設置' },
  { id: '12', name: '洗濯機縦型7kg以上', price: 6300, category: '設置' },
  { id: '13', name: '洗濯機縦型7kg以上', price: 4000, category: '設置', subCategory: '搬出のみ' },
  { id: '14', name: '洗濯機縦型7kg未満', price: 5500, category: '設置' },
  { id: '15', name: '洗濯機縦型7kg未満', price: 4000, category: '設置', subCategory: '搬出のみ' },
  { id: '16', name: '洗濯機置き台', price: 6300, category: '設置' },
  { id: '17', name: 'テレビ66-75型', price: 12000, category: '設置' },
  { id: '18', name: 'テレビ66-75型', price: 17000, category: '設置', subCategory: '搬出のみ' },
  { id: '19', name: 'テレビ51-65型', price: 8000, category: '設置' },
  { id: '20', name: 'テレビ51-65型', price: 12500, category: '設置', subCategory: '搬出のみ' },
  { id: '21', name: 'テレビ33-50型', price: 6000, category: '設置' },
  { id: '22', name: 'テレビ33-50型', price: 7800, category: '設置', subCategory: '搬出のみ' },
  { id: '23', name: 'テレビ32型以下', price: 4000, category: '設置' },
  { id: '24', name: 'エアコン(リサイクル)', price: 13000, category: '設置' },
  { id: '25', name: 'エアーサーバー', price: 10800, category: '設置' },
  { id: '26', name: 'ブルーレイ/DVDレコーダー', price: 4300, category: '設置' },
  { id: '27', name: 'ホットカーペット', price: 4300, category: '設置' },
  { id: '28', name: 'オーブンレンジ', price: 4300, category: '設置' },
  { id: '29', name: 'デスクトップパソコン', price: 4300, category: '設置' },
  { id: '30', name: 'アルカリイオン整水器/浄水器', price: 4300, category: '設置' },
  { id: '31', name: '食器洗い機', price: 3000, category: '設置' },
  { id: '32', name: '小型商品1個', price: 900, category: '設置' },
  { id: '33', name: '冷蔵庫400L未満', price: 5000, category: '搬出' },
  { id: '34', name: '冷蔵庫400-499Lサイズ', price: 8000, category: '搬出' },
  { id: '35', name: '冷蔵庫500-599Lサイズ', price: 8500, category: '搬出' },
  { id: '36', name: '冷蔵庫600Lサイズ', price: 8500, category: '搬出' },
  { id: '37', name: '洗濯機（ドラム式以外）7kg未満', price: 4000, category: '搬出' },
  { id: '38', name: '洗濯機（ドラム式以外）7kg以上', price: 4000, category: '搬出' },
  { id: '39', name: 'テレビ（32型以下）', price: 4000, category: '搬出' },
  { id: '40', name: 'テレビ（51-65型以下）', price: 5000, category: '搬出' },
  { id: '41', name: 'テレビ（66-75型以下）', price: 7000, category: '搬出' },
  { id: '42', name: '指定商品買入（1台）', price: 1500, category: '搬出' },
  { id: '43', name: '指定商品', price: 2000, category: '搬出' },
  { id: '44', name: '重量物商品', price: 5000, category: '搬出' },
  { id: '45', name: '特殊商品', price: 3000, category: '搬出' },
  { id: '46', name: '人員増員', price: 8000, category: '搬出' },
  { id: '47', name: 'ドア取り外し取り付け', price: 5000, category: '搬出' },
  { id: '48', name: '手すり取り外し', price: 5000, category: '搬出' },
  { id: '49', name: 'リサイクル品引取費', price: 2500, category: 'リサイクル' },
  { id: '50', name: 'リサイクル費（リサイクル券代込み）冷蔵庫', price: 4600, category: 'リサイクル' },
  { id: '51', name: 'リサイクル費（リサイクル券代込み）冷凍庫170L以上', price: 4600, category: 'リサイクル' },
  { id: '52', name: '冷蔵庫取り・配送費', price: 2000, category: 'リサイクル' },
  { id: '53', name: 'エレベーター無し', price: 25000, category: 'リサイクル' },
  { id: '54', name: 'エレベーター有り', price: 20000, category: 'リサイクル' },
  { id: '55', name: 'エレベーター有り', price: 40000, category: 'リサイクル' },
];

const PriceList: React.FC = () => {
  return (
    <div className="bg-white shadow-md rounded-lg overflow-hidden">
      <div className="px-4 py-5 sm:px-6">
        <h3 className="text-lg leading-6 font-medium text-pink-800">料金表</h3>
        <p className="mt-1 max-w-2xl text-sm text-gray-500">設置・搬出・リサイクル作業の料金一覧</p>
      </div>
      <div className="border-t border-gray-200">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-pink-50">
            <tr>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-pink-800 uppercase tracking-wider">
                作業内容
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-pink-800 uppercase tracking-wider">
                カテゴリ
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-pink-800 uppercase tracking-wider">
                サブカテゴリ
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-pink-800 uppercase tracking-wider">
                料金
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {priceList.map((item) => (
              <tr key={item.id}>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{item.name}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{item.category}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{item.subCategory || '-'}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">¥{item.price.toLocaleString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default PriceList;
export { priceList };