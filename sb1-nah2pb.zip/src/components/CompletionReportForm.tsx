import React, { useState } from 'react';
import { Search } from 'lucide-react';

const CompletionReportForm = ({ deliveries, updateDelivery }) => {
  const [selectedDelivery, setSelectedDelivery] = useState(null);
  const [additionalDistance, setAdditionalDistance] = useState('');
  const [highwayFee, setHighwayFee] = useState('');
  const [parkingFee, setParkingFee] = useState('');
  const [oldModelNumber, setOldModelNumber] = useState('');
  const [approvalNumber, setApprovalNumber] = useState('');
  const [stoNumber, setStoNumber] = useState('');
  const [serialNumber, setSerialNumber] = useState('');
  const [searchTerm, setSearchTerm] = useState('');

  const handleDeliverySelect = (e) => {
    const delivery = deliveries.find(d => d.id === parseInt(e.target.value));
    setSelectedDelivery(delivery);
  };

  const calculateTotalFee = () => {
    const baseFee = selectedDelivery ? parseFloat(selectedDelivery.price) : 0;
    const additionalFee = parseFloat(additionalDistance) * 100; // 1kmあたり100円と仮定
    const totalHighwayFee = parseFloat(highwayFee) || 0;
    const totalParkingFee = parseFloat(parkingFee) || 0;
    return baseFee + additionalFee + totalHighwayFee + totalParkingFee;
  };

  const filteredDeliveries = deliveries.filter(d => 
    d.status === '完了待ち' && 
    (d.workOrderNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
     d.customerName.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  const handleSubmit = (e) => {
    e.preventDefault();
    const totalFee = calculateTotalFee();
    const updatedDelivery = {
      ...selectedDelivery,
      status: '返品待ち',
      additionalDistance,
      highwayFee,
      parkingFee,
      oldModelNumber,
      approvalNumber,
      stoNumber,
      serialNumber,
      totalFee
    };
    updateDelivery(updatedDelivery);
    // フォームをリセット
    setSelectedDelivery(null);
    setAdditionalDistance('');
    setHighwayFee('');
    setParkingFee('');
    setOldModelNumber('');
    setApprovalNumber('');
    setStoNumber('');
    setSerialNumber('');
  };

  return (
    <div className="bg-white shadow rounded-lg p-6">
      <h2 className="text-xl font-semibold mb-4 text-pink-800">完了報告作成</h2>
      <div className="mb-4">
        <label htmlFor="search" className="block text-sm font-medium text-pink-700">配送依頼検索</label>
        <div className="mt-1 relative rounded-md shadow-sm">
          <input
            type="text"
            id="search"
            className="focus:ring-pink-500 focus:border-pink-500 block w-full pl-10 sm:text-sm border-pink-300 rounded-md"
            placeholder="作業番号または顧客名で検索"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search className="h-5 w-5 text-gray-400" />
          </div>
        </div>
      </div>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label htmlFor="delivery" className="block text-sm font-medium text-pink-700">配送依頼選択</label>
          <select
            id="delivery"
            onChange={handleDeliverySelect}
            className="mt-1 block w-full rounded-md border-pink-300 shadow-sm focus:border-pink-300 focus:ring focus:ring-pink-200 focus:ring-opacity-50"
          >
            <option value="">選択してください</option>
            {filteredDeliveries.map((delivery) => (
              <option key={delivery.id} value={delivery.id}>
                {delivery.workOrderNumber} - {delivery.customerName}
              </option>
            ))}
          </select>
        </div>

        {selectedDelivery && (
          <>
            <div>
              <label htmlFor="additionalDistance" className="block text-sm font-medium text-pink-700">距離加算</label>
              <input
                type="number"
                id="additionalDistance"
                value={additionalDistance}
                onChange={(e) => setAdditionalDistance(e.target.value)}
                className="mt-1 block w-full rounded-md border-pink-300 shadow-sm focus:border-pink-300 focus:ring focus:ring-pink-200 focus:ring-opacity-50"
                placeholder="追加距離（km）"
              />
            </div>

            <div>
              <label htmlFor="highwayFee" className="block text-sm font-medium text-pink-700">高速料金</label>
              <input
                type="number"
                id="highwayFee"
                value={highwayFee}
                onChange={(e) => setHighwayFee(e.target.value)}
                className="mt-1 block w-full rounded-md border-pink-300 shadow-sm focus:border-pink-300 focus:ring focus:ring-pink-200 focus:ring-opacity-50"
                placeholder="高速料金（円）"
              />
            </div>

            <div>
              <label htmlFor="parkingFee" className="block text-sm font-medium text-pink-700">駐車場料金</label>
              <input
                type="number"
                id="parkingFee"
                value={parkingFee}
                onChange={(e) => setParkingFee(e.target.value)}
                className="mt-1 block w-full rounded-md border-pink-300 shadow-sm focus:border-pink-300 focus:ring focus:ring-pink-200 focus:ring-opacity-50"
                placeholder="駐車場料金（円）"
              />
            </div>

            <div>
              <label htmlFor="oldModelNumber" className="block text-sm font-medium text-pink-700">旧型番</label>
              <input
                type="text"
                id="oldModelNumber"
                value={oldModelNumber}
                onChange={(e) => setOldModelNumber(e.target.value)}
                className="mt-1 block w-full rounded-md border-pink-300 shadow-sm focus:border-pink-300 focus:ring focus:ring-pink-200 focus:ring-opacity-50"
                placeholder="旧型番を入力"
              />
            </div>

            <div>
              <label htmlFor="approvalNumber" className="block text-sm font-medium text-pink-700">承認番号</label>
              <input
                type="text"
                id="approvalNumber"
                value={approvalNumber}
                onChange={(e) => setApprovalNumber(e.target.value)}
                className="mt-1 block w-full rounded-md border-pink-300 shadow-sm focus:border-pink-300 focus:ring focus:ring-pink-200 focus:ring-opacity-50"
                placeholder="承認番号を入力"
              />
            </div>

            <div>
              <label htmlFor="stoNumber" className="block text-sm font-medium text-pink-700">STO番号</label>
              <input
                type="text"
                id="stoNumber"
                value={stoNumber}
                onChange={(e) => setStoNumber(e.target.value)}
                className="mt-1 block w-full rounded-md border-pink-300 shadow-sm focus:border-pink-300 focus:ring focus:ring-pink-200 focus:ring-opacity-50"
                placeholder="STO番号を入力"
              />
            </div>

            <div>
              <label htmlFor="serialNumber" className="block text-sm font-medium text-pink-700">製造番号</label>
              <input
                type="text"
                id="serialNumber"
                value={serialNumber}
                onChange={(e) => setSerialNumber(e.target.value)}
                className="mt-1 block w-full rounded-md border-pink-300 shadow-sm focus:border-pink-300 focus:ring focus:ring-pink-200 focus:ring-opacity-50"
                placeholder="製造番号を入力"
              />
            </div>

            <div>
              <label htmlFor="totalFee" className="block text-sm font-medium text-pink-700">合計金額</label>
              <input
                type="text"
                id="totalFee"
                value={`¥${calculateTotalFee().toLocaleString()}`}
                readOnly
                className="mt-1 block w-full rounded-md border-pink-300 shadow-sm focus:border-pink-300 focus:ring focus:ring-pink-200 focus:ring-opacity-50 bg-gray-100"
              />
            </div>

            <button
              type="submit"
              className="w-full bg-pink-500 text-white py-2 px-4 rounded-md hover:bg-pink-600 focus:outline-none focus:ring-2 focus:ring-pink-500 focus:ring-opacity-50 transition duration-300"
            >
              完了報告を送信
            </button>
          </>
        )}
      </form>
    </div>
  );
};

export default CompletionReportForm;