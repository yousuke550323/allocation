import React from 'react';
import { DollarSign, TrendingUp, Package } from 'lucide-react';

const SalesSummary = ({ deliveries }) => {
  const totalSales = deliveries.reduce((sum, delivery) => sum + Number(delivery.price), 0);
  const completedDeliveries = deliveries.filter(d => d.status === '完了').length;
  const pendingDeliveries = deliveries.filter(d => d.status === '保留中').length;

  return (
    <div className="bg-white shadow rounded-lg p-6">
      <h2 className="text-xl font-semibold mb-4 text-pink-800">売上概要</h2>
      <div className="space-y-4">
        <SummaryItem
          icon={<DollarSign className="text-green-400" size={24} />}
          title="総売上"
          value={`¥${totalSales.toLocaleString()}`}
        />
        <SummaryItem
          icon={<TrendingUp className="text-blue-400" size={24} />}
          title="完了した配送"
          value={completedDeliveries}
        />
        <SummaryItem
          icon={<Package className="text-yellow-400" size={24} />}
          title="保留中の配送"
          value={pendingDeliveries}
        />
      </div>
    </div>
  );
};

const SummaryItem = ({ icon, title, value }) => (
  <div className="flex items-center p-3 bg-pink-50 rounded-lg">
    {icon}
    <div className="ml-3">
      <p className="text-sm text-gray-600">{title}</p>
      <p className="text-lg font-semibold text-pink-700">{value}</p>
    </div>
  </div>
);

export default SalesSummary;