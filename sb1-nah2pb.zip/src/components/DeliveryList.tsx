import React, { useState } from 'react';
import { CheckCircle, XCircle, Edit2, Save, Refrigerator, WashingMachine, Tv, Wind } from 'lucide-react';

const DeliveryList = ({ deliveries, updateStatus, updateNotes }) => {
  const [editingId, setEditingId] = useState(null);
  const [editedNotes, setEditedNotes] = useState('');

  const statusColors = {
    '未確定': 'bg-yellow-100 text-yellow-800',
    '完了待ち': 'bg-blue-100 text-blue-800',
    '返品待ち': 'bg-green-100 text-green-800',
    'キャンセル': 'bg-red-100 text-red-800',
  };

  const handleEditNotes = (id, currentNotes) => {
    setEditingId(id);
    setEditedNotes(currentNotes);
  };

  const handleSaveNotes = (id) => {
    updateNotes(id, editedNotes);
    setEditingId(null);
  };

  const getItemIcon = (item) => {
    if (item.toLowerCase().includes('冷蔵庫')) return <Refrigerator className="text-blue-500" />;
    if (item.toLowerCase().includes('洗濯機')) return <WashingMachine className="text-green-500" />;
    if (item.toLowerCase().includes('テレビ')) return <Tv className="text-purple-500" />;
    if (item.toLowerCase().includes('エアコン')) return <Wind className="text-red-500" />;
    return null;
  };

  return (
    <div className="bg-white shadow rounded-lg p-6">
      <h2 className="text-xl font-semibold mb-4 text-pink-800">配送依頼一覧</h2>
      {deliveries.length === 0 ? (
        <p className="text-gray-500">配送依頼はまだありません。</p>
      ) : (
        <ul className="space-y-4">
          {deliveries.map((delivery) => (
            <li key={delivery.id} className="border-b pb-4 last:border-b-0">
              <div className="flex justify-between items-start">
                <div className="flex items-center">
                  {getItemIcon(delivery.installationWork)}
                  <div className="ml-2">
                    <h3 className="font-semibold text-pink-700">{delivery.customerName}</h3>
                    <p className="text-sm text-gray-600">{delivery.customerAddress}</p>
                    <p className="text-sm text-gray-600">品目: {delivery.installationWork}</p>
                    <p className="text-sm font-semibold text-green-600">¥{Number(delivery.price).toLocaleString()}</p>
                    {editingId === delivery.id ? (
                      <div className="mt-2">
                        <textarea
                          value={editedNotes}
                          onChange={(e) => setEditedNotes(e.target.value)}
                          className="w-full p-2 border rounded"
                        />
                        <button
                          onClick={() => handleSaveNotes(delivery.id)}
                          className="mt-2 bg-pink-500 text-white px-2 py-1 rounded text-sm"
                        >
                          <Save size={16} className="inline mr-1" /> 保存
                        </button>
                      </div>
                    ) : (
                      <p className="text-sm text-gray-600 mt-2">
                        備考: {delivery.notes || 'なし'}
                        <button
                          onClick={() => handleEditNotes(delivery.id, delivery.notes)}
                          className="ml-2 text-pink-500 hover:text-pink-700"
                        >
                          <Edit2 size={16} />
                        </button>
                      </p>
                    )}
                  </div>
                </div>
                <div className="text-right">
                  <span className={`inline-block px-2 py-1 rounded-full text-xs font-semibold ${statusColors[delivery.status]}`}>
                    {delivery.status}
                  </span>
                  {delivery.status === '未確定' && (
                    <div className="mt-2 space-x-2">
                      <button
                        onClick={() => updateStatus(delivery.id, '完了待ち')}
                        className="text-green-500 hover:text-green-700"
                      >
                        <CheckCircle size={20} />
                      </button>
                      <button
                        onClick={() => updateStatus(delivery.id, 'キャンセル')}
                        className="text-red-500 hover:text-red-700"
                      >
                        <XCircle size={20} />
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default DeliveryList;