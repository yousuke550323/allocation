import React from 'react';
import { DollarSign, TrendingUp, Package, Clock } from 'lucide-react';
import DeliveryList from './DeliveryList';
import SalesSummary from './SalesSummary';

const Dashboard = ({ deliveries, updateStatus, updateNotes }) => {
  const totalSales = deliveries.reduce((sum, delivery) => sum + Number(delivery.price), 0);
  const completedDeliveries = deliveries.filter(d => d.status === '完了待ち').length;
  const pendingDeliveries = deliveries.filter(d => d.status === '未確定').length;

  // 平均日数の計算
  const calculateAverageDays = () => {
    const returningDeliveries = deliveries.filter(d => d.status === '返品待ち' && d.createdAt && d.updatedAt);
    if (returningDeliveries.length === 0) return 0;

    const totalDays = returningDeliveries.reduce((sum, delivery) => {
      const createdDate = new Date(delivery.createdAt);
      const updatedDate = new Date(delivery.updatedAt);
      const diffTime = Math.abs(updatedDate - createdDate);
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      return sum + diffDays;
    }, 0);

    return Math.round(totalDays / returningDeliveries.length);
  };

  const averageDays = calculateAverageDays();

  return (
    <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
      <div className="md:col-span-3">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-4">
          <DashboardCard
            title="総売上"
            value={`¥${totalSales.toLocaleString()}`}
            icon={<DollarSign className="text-green-400" size={24} />}
            color="bg-green-100"
          />
          <DashboardCard
            title="完了待ちの配送"
            value={completedDeliveries}
            icon={<TrendingUp className="text-blue-400" size={24} />}
            color="bg-blue-100"
          />
          <DashboardCard
            title="未確定の配送"
            value={pendingDeliveries}
            icon={<Package className="text-yellow-400" size={24} />}
            color="bg-yellow-100"
          />
          <DashboardCard
            title="平均返品待ち日数"
            value={`${averageDays}日`}
            icon={<Clock className="text-purple-400" size={24} />}
            color="bg-purple-100"
          />
        </div>
        <DeliveryList deliveries={deliveries} updateStatus={updateStatus} updateNotes={updateNotes} />
      </div>
      <div>
        <SalesSummary deliveries={deliveries} />
      </div>
    </div>
  );
};

const DashboardCard = ({ title, value, icon, color }) => (
  <div className={`${color} rounded-lg p-4 shadow-md`}>
    <div className="flex items-center justify-between">
      <div>
        <p className="text-sm font-medium text-gray-600">{title}</p>
        <p className="text-2xl font-semibold mt-1">{value}</p>
      </div>
      {icon}
    </div>
  </div>
);

export default Dashboard;