import React, { useState } from 'react';
import { priceList, PriceItem } from './PriceList';

const DeliveryRequestForm = ({ onSubmit }) => {
  const [formData, setFormData] = useState({
    workOrderNumber: '',
    client: '',
    area: '',
    customerName: '',
    customerAddress: '',
    contactNumber: '',
    installationWork: '',
    removalContent: '',
    productModel: '',
    price: 0,
    notes: '',
    registrationDate: new Date().toISOString().split('T')[0],
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });

    if (name === 'installationWork' || name === 'removalContent') {
      const selectedItem = priceList.find((item) => item.name === value);
      if (selectedItem) {
        setFormData((prevData) => ({
          ...prevData,
          [name]: value,
          price: prevData.price + selectedItem.price,
        }));
      }
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
  };

  const clients = ['ハイアール', '東芝', '販売店', 'AQUA', 'その他'];
  const areas = [
    '東京', '神奈川', '長野', '名古屋(ｸﾛﾉｽ)', '豊橋', '福井(ｸｸﾙ)', 
    '北海道(ｸﾛｰﾊﾞｰ)', '静岡(ｸﾛﾉｽ)', '大阪(SS運送)', '八潮', 
    '大阪(ﾀｹﾓﾄ)', '盛岡', '徳島', '愛媛(ﾌﾞﾙｷｬｯﾂ)'
  ];
  const installationWorks = priceList.filter((item) => item.category === '設置' && !item.subCategory).map((item) => item.name);
  const removalContents = priceList.filter((item) => item.category === '搬出' || (item.category === '設置' && item.subCategory === '搬出のみ')).map((item) => item.name);

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <label htmlFor="workOrderNumber" className="block text-sm font-medium text-pink-700">作業登録番号</label>
        <input
          type="text"
          id="workOrderNumber"
          name="workOrderNumber"
          value={formData.workOrderNumber}
          onChange={handleChange}
          required
          className="mt-1 block w-full rounded-md border-pink-300 shadow-sm focus:border-pink-300 focus:ring focus:ring-pink-200 focus:ring-opacity-50"
        />
      </div>

      <div>
        <label htmlFor="client" className="block text-sm font-medium text-pink-700">依頼元</label>
        <select
          id="client"
          name="client"
          value={formData.client}
          onChange={handleChange}
          required
          className="mt-1 block w-full rounded-md border-pink-300 shadow-sm focus:border-pink-300 focus:ring focus:ring-pink-200 focus:ring-opacity-50"
        >
          <option value="">選択してください</option>
          {clients.map((client) => (
            <option key={client} value={client}>{client}</option>
          ))}
        </select>
      </div>

      <div>
        <label htmlFor="area" className="block text-sm font-medium text-pink-700">エリア</label>
        <select
          id="area"
          name="area"
          value={formData.area}
          onChange={handleChange}
          required
          className="mt-1 block w-full rounded-md border-pink-300 shadow-sm focus:border-pink-300 focus:ring focus:ring-pink-200 focus:ring-opacity-50"
        >
          <option value="">選択してください</option>
          {areas.map((area) => (
            <option key={area} value={area}>{area}</option>
          ))}
        </select>
      </div>

      <div>
        <label htmlFor="customerName" className="block text-sm font-medium text-pink-700">お客様名</label>
        <input
          type="text"
          id="customerName"
          name="customerName"
          value={formData.customerName}
          onChange={handleChange}
          required
          className="mt-1 block w-full rounded-md border-pink-300 shadow-sm focus:border-pink-300 focus:ring focus:ring-pink-200 focus:ring-opacity-50"
        />
      </div>

      <div>
        <label htmlFor="customerAddress" className="block text-sm font-medium text-pink-700">お客様住所</label>
        <input
          type="text"
          id="customerAddress"
          name="customerAddress"
          value={formData.customerAddress}
          onChange={handleChange}
          required
          className="mt-1 block w-full rounded-md border-pink-300 shadow-sm focus:border-pink-300 focus:ring focus:ring-pink-200 focus:ring-opacity-50"
        />
      </div>

      <div>
        <label htmlFor="contactNumber" className="block text-sm font-medium text-pink-700">連絡先</label>
        <input
          type="tel"
          id="contactNumber"
          name="contactNumber"
          value={formData.contactNumber}
          onChange={handleChange}
          required
          className="mt-1 block w-full rounded-md border-pink-300 shadow-sm focus:border-pink-300 focus:ring focus:ring-pink-200 focus:ring-opacity-50"
        />
      </div>

      <div>
        <label htmlFor="installationWork" className="block text-sm font-medium text-pink-700">設置作業内容</label>
        <select
          id="installationWork"
          name="installationWork"
          value={formData.installationWork}
          onChange={handleChange}
          required
          className="mt-1 block w-full rounded-md border-pink-300 shadow-sm focus:border-pink-300 focus:ring focus:ring-pink-200 focus:ring-opacity-50"
        >
          <option value="">選択してください</option>
          {installationWorks.map((work) => (
            <option key={work} value={work}>{work}</option>
          ))}
        </select>
      </div>

      <div>
        <label htmlFor="removalContent" className="block text-sm font-medium text-pink-700">搬出商品内容</label>
        <select
          id="removalContent"
          name="removalContent"
          value={formData.removalContent}
          onChange={handleChange}
          required
          className="mt-1 block w-full rounded-md border-pink-300 shadow-sm focus:border-pink-300 focus:ring focus:ring-pink-200 focus:ring-opacity-50"
        >
          <option value="">選択してください</option>
          {removalContents.map((content) => (
            <option key={content} value={content}>{content}</option>
          ))}
        </select>
      </div>

      <div>
        <label htmlFor="productModel" className="block text-sm font-medium text-pink-700">設置型番</label>
        <input
          type="text"
          id="productModel"
          name="productModel"
          value={formData.productModel}
          onChange={handleChange}
          className="mt-1 block w-full rounded-md border-pink-300 shadow-sm focus:border-pink-300 focus:ring focus:ring-pink-200 focus:ring-opacity-50"
        />
      </div>

      <div>
        <label htmlFor="notes" className="block text-sm font-medium text-pink-700">備考</label>
        <textarea
          id="notes"
          name="notes"
          value={formData.notes}
          onChange={handleChange}
          className="mt-1 block w-full rounded-md border-pink-300 shadow-sm focus:border-pink-300 focus:ring focus:ring-pink-200 focus:ring-opacity-50"
          rows={3}
        ></textarea>
      </div>

      <div>
        <label htmlFor="price" className="block text-sm font-medium text-pink-700">合計金額</label>
        <input
          type="text"
          id="price"
          name="price"
          value={`¥${formData.price.toLocaleString()}`}
          readOnly
          className="mt-1 block w-full rounded-md border-pink-300 shadow-sm focus:border-pink-300 focus:ring focus:ring-pink-200 focus:ring-opacity-50 bg-gray-100"
        />
      </div>

      <button
        type="submit"
        className="w-full bg-pink-500 text-white py-2 px-4 rounded-md hover:bg-pink-600 focus:outline-none focus:ring-2 focus:ring-pink-500 focus:ring-opacity-50 transition duration-300"
      >
        依頼を送信
      </button>
    </form>
  );
};

export default DeliveryRequestForm;