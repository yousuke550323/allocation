import React from 'react';
import PriceList from '../components/PriceList';

const PriceListPage: React.FC = () => {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold text-pink-800 mb-6">料金表</h1>
      <div className="mb-8">
        <img
          src="https://images.unsplash.com/photo-1586864387967-d02ef85d93e8?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80"
          alt="配送トラック"
          className="w-full h-64 object-cover rounded-lg shadow-md"
        />
      </div>
      <PriceList />
    </div>
  );
};

export default PriceListPage;